from SearchTree.Node import Node
from SearchTree.Tree import Tree


from SearchTree.NetworkSearchTree import NetworkSearchTree
from SearchTree.NPuzzleSearchTree import NPuzzleSearchTree